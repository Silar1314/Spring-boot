package test.ejb;

public interface BaseEntityHome{}